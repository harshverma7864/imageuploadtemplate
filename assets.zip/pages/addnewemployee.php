<?php include '../assets/partials/_dbconnect.php'; ?>
<?php include '../assets/partials/_headers.php'; ?>
<section class="section">
<?php
if(isset($_GET['alert'])){
    echo '   <div style="z-index:0;" class="alert alert-success alert-dismissible fade show" role="alert">
    <strong></strong> '.$_GET['alert'].'
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
?>
<form action=" /assets/partials/adduser.php" method="post">
<div class="row">
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Username</label>
                    <input type="text" class="form-control" name="username"  id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                    <input type="text" class="form-control" name="name"  id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Confirm Password</label>
                    <input type="text" class="form-control" name="cpassword" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>

            </div>

<div class="buttons d-flex justify-content-center">
    <button type="submit" class="btn btn-primary my-2 mx-2" >Submit</button>
    <div class="btn btn-danger my-2 mx-2">Cancel</div>
</div>';



</form>
    </section>
    <footer class="foot">
    <h5>2022 @ KBN CRM</h5>
    <h5>kbnsoftwarepvt@gmail.com</h5>
    </footer>

    


<script>







$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>