
<?php

function getEmployeeData($conn,$role){
    if ($role == "admin") {
        $sql = "Select * from employee";
    $result = mysqli_query($conn,$sql);
    return $result;
    }
    
}


function getAppointmentData($conn,$role){
        $email = $_SESSION['email'];
        if ($role == "admin") {
            $sql = "Select a.* , c.name as custname from crmappointmentm a inner Join customer c on a.custId = c.custid";
            $result = mysqli_query($conn,$sql);
        }
        if ($role == "user") {
            $ed = $_SESSION['eid'];
            $sql = "Select a.* , c.name as custname from crmappointmentm a inner Join customer c on a.custId = c.custid and a.empId = '$ed'";
            $result = mysqli_query($conn,$sql);
        }
        return $result;
}

    
function getUserData($conn , $uemail){
    $sql = "select * from users where email = $uemail";
    $result = mysqli_query($conn,$sql);
    return result;
}


function getCustomerData($conn){
    
        $sql = "Select * from customer";
        $result = mysqli_query($conn,$sql);
        return $result;
    
}

function getProductData($conn,$role){
    if ($role == "admin") {
        $sql = "Select * from product";
        $result = mysqli_query($conn,$sql);
        return $result;
    }
}
function getPotentials($conn){
        $sql = "Select * from potentials";
        $result = mysqli_query($conn,$sql);
        return $result;
 
}


function fillfield($conn){
    $a = `<script> console.log("hi sir"); </script>`;
    return $a;

}


function getFilterData($conn,$role,$fdate, $tdate,$ffdate,$ftdate, $ename, $cname,$status){
  
    $finaladminsql = "Select a.* , c.name as custname from crmappointmentm a inner Join customer c on a.custId = c.custid";
    $finalusersql = "Select a.* , c.name as custname from crmappointmentm a inner Join customer c on a.custId = c.custid and a.empId = '$ed' and a.visitDate >= '$fdate' and a.visitDate <= '$tdate' and a.empId = '$ename' and a.companyName = '$cname'";
    $filtersql = " ";
    if ($fdate != "") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        $filtersql = $filtersql."a.visitDate >= '$fdate'";
    }
    if ($tdate != "") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        else{
            $filtersql = $filtersql."and ";
        }
        $filtersql = $filtersql."a.visitDate <= '$tdate'";
    }
    if ($ffdate != "") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        else{
            $filtersql = $filtersql."and ";
        }
        $filtersql = $filtersql."a.followUp_date >= '$ffdate'";
    }
    if ($ftdate != "") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        else{
            $filtersql = $filtersql."and ";
        }
        $filtersql = $filtersql."a.followUp_date <= '$ftdate'";
    }
    if ($ename != "all") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        else{
            $filtersql = $filtersql."and ";
        }
        $filtersql = $filtersql."a.empId = '$ename'";
    }
    if ($cname != "all") {
        if ($filtersql == " ") {
            $filtersql = " where ";
        }
        else{
            $filtersql = $filtersql." and ";
        }
        $filtersql = $filtersql."a.companyName = '$cname'";
    }
    if ($status != "all") {
        if ($filtersql == " ") {
            $filtersql = "where ";
        }
        else{
            $filtersql = $filtersql." and ";
        }
        $filtersql = $filtersql."a.status = '$status'";
    }

    $finaladminsql = $finaladminsql.$filtersql;
    $finalusersql = $finalusersql.$filtersql;
  
    $email = $_SESSION['email'];
        if ($role == "admin") {
            $result = mysqli_query($conn,$finaladminsql);
        }
        if ($role == "user") {
            $result = mysqli_query($conn,$finalusersql);
        }
        return $result;
}



function filterPotentials($toDate,$fDate,$accnme){

    $sql = "select COUNT * from potentials where accname = $accnme";

    if ($tdate!= "" && $fdate != "") {
        $sql =  $sql."and nsdd >= '$fDate' and nsdd <= '$toDate'";
    }

    else if ($toDate != "" && $fDate == ""){
        $sql =  $sql."and nsdd <= '$toDate'"; 
    }

    else if($toDate == "" && $fDate != ""){
        $sql =  $sql."and nsdd >= '$fDate'"; 
    }

    $result = mysqli_query($conn, $sql);
    return result;
}



function getFilterPotential($conn, $search, $fdate, $tdate){
    $filter  = "select COUNT(*) as number from potentials  where ";
    
    if ($search != "") {
        $filter .= " potname like '%$search%'";
    }
    if ($fdate != "") {
        if ($search != "") {
            $filter .= " and exclosuredate > '$fdate'";
        }
        else{
            $filter .= " exclosuredate > '$fdate'";
        }
    }
    if ($tdate != "") {
        if ($search != "" || $fdate != "") {
            $filter .= " and exclosuredate < '$tdate'";
        }
        else{
            $filter .= " exclosuredate < '$tdate'";
        }
    }

    return $filter;
}




function getFilteredPot($search, $powner, $stage, $ptype, $fdate, $tdate){
    $filter  = "select * from potentials  where ";
    
    if ($search != "") {
        $filter .= " potname like '%$search%'";
    }
    if ($fdate != "") {
        if ($search != "") {
            $filter .= " and exclosuredate > '$fdate'";
        }
        else{
            $filter .= " exclosuredate > '$fdate'";
        }
    }
    if ($tdate != "") {
        if ($search != "" || $fdate != "") {
            $filter .= " and exclosuredate < '$tdate'";
        }
        else{
            $filter .= " exclosuredate < '$tdate'";
        }
    }
    if ($powner != "") {
        if ($search != "" || $fdate != "" || $tdate != "") {
            $filter .= " and owner = '$powner'";
        }
        else{
            $filter .= " owner = '$powner'";
        }
    }
    if ($stage != "") {
        if ($search != "" || $fdate != "" || $tdate != "" || $powner != "") {
            $filter .= " and stage = '$stage'";
        }
        else{
            $filter .= " stage = '$stage'";
        }
    }
     

    return $filter;
}
?>