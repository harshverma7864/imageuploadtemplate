<?php
include "./_dbconnect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];


    $sql1 = "select username from users where username = '$username'";
    $result1 = mysqli_query($conn, $sql1);


    if (mysqli_num_rows($result1) != 0) {
        $alert = "user already exist";
        header("location:   /pages/addnewemployee.php?alert=$alert");
    }


    else{
    
    if ($password == $cpassword) {

    $sql = "insert into users (`username`, `name`, `password`) values ('$username', '$name','$password')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $alert = "user added successfully";
        header("location:   /pages/addnewemployee.php?alert=$alert");
    }
    else{
        $alert = "error adding user";
        header("location:   /pages/addnewemployee.php?alert=$alert");
    }
}
else{
    $alert = "Paassword and confirm password must be same";
    header("location:   /pages/addnewemployee.php?alert=$alert"); 
}
}
  
}



?>