<?php

include './_dbconnect.php';

$_SESSION['loggedin'] = false;

if ($_SERVER['REQUEST_METHOD'] =='POST') {
    $username = $_POST['username'];
    $pass = $_POST['password'];

    $sql = "select * from users where username = '$username' and password = '$pass'";
    $result = mysqli_query($conn, $sql);
   
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        session_start();
        $_SESSION['name'] = $row['name'];
        $_SESSION['loggedin'] = true;
        header("location:    /pages/dashboard.php");
    }
}


?>